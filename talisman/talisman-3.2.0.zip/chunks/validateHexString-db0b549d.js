const t=r=>{if(typeof r!="string")throw new Error("Expected a string");if(r.startsWith("0x"))return r;throw new Error("Expected a hex string")};export{t as v};
