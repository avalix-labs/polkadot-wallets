import{e8 as r}from"./index.esm-ec40baaa.js";function t(o){return o?r(o).toNumber():NaN}export{t as h};
